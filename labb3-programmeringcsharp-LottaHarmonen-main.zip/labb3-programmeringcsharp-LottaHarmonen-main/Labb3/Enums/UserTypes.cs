﻿namespace Labb3ProgTemplate.Enums;

public enum UserTypes
{
    Admin,
    Customer,
}