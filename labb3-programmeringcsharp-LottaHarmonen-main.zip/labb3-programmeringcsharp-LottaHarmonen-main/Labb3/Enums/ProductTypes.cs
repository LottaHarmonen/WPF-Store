﻿namespace Labb3ProgTemplate.Enums;

public enum ProductTypes
{
    Dairy,
    Meat,
    Fruit

}